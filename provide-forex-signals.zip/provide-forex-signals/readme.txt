=== Provide Forex Signals ===
Contributors: Codeies
Donate link: #
Tags: forex,signal,live signal,forex signal provider
Requires at least: 4.0
Tested up to: 5.5
Stable tag: 1.0
Requires PHP: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin can be used to provide signals manually to your clients 

== Description ==

This plugin can be used to provide signals manually to your clients 

Features:

1. Your Client will get live signals 
2. Generate Unlimited Signal boxes and Generator
3. Easy Integration , using 2 shortcodes


== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/provide-forex-signals` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Add or edit new blog post, 
 & configure settings 
4. Add shortcode [fsp_generator id=1] to the page from where you want to send signals to your client
5. Add shortcode to the page where your clients will recieve the signals [fsp_lists id=1]
== Frequently Asked Questions ==



= Who can use this plugin =

This plugin is not for you if you are looking for live signals, This plugin is for those sites who sends live signal to their clients

= Do you have the pro version ? =

No we don't have any , If you are interested in more features leave your feedback we always try to improve our plugin as much as possible



== Changelog ==

07/07/2021
- Initial Release

== Upgrade Notice ==

